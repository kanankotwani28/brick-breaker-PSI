/* =====================================================================
   Brick Breaker — remote asset loader
   =====================================================================

   Gives Brick Breaker the same dynamic-asset behaviour the Flutter game
   already has: rather than only using the art baked into index.html, the
   game asks the backend which collection is live and swaps those sprites
   in at boot.

   Brick Breaker keeps every sprite in one object:

       const SPRITES = { ball: "data:image/png;base64,...", brick0: "...", ... }

   and Boot.preload() does `this.load.image(key, SPRITES[key])`. Phaser's
   loader treats a URL and a data URI identically, so the whole integration
   is: rewrite the values of that object before the loader runs. Nothing in
   the scenes, the loader or any draw call has to change.

   Matching is by asset NAME. Upload a sprite named `brick0` and it replaces
   the brick0 texture; upload one named `paddle` and it replaces the paddle.

   ---------------------------------------------------------------------
   Two rules this module will not bend:

   1. FAIL OPEN. A backend that is down, slow, unreachable or returning
      nonsense must leave the game exactly as it was. This runs on a
      player's phone, and the analytics backend being unavailable is never
      a reason for the game not to start. Every failure path returns the
      SPRITES object unmodified.

   2. NEVER INTRODUCE A KEY. Only keys already present in SPRITES are
      overridden. An upload named `xyz` is ignored rather than creating a
      texture nothing draws — and, more to the point, an upload named
      `__proto__` cannot reach Object.prototype.
   ===================================================================== */
(function (global) {
  'use strict';

  var DEFAULTS = {
    baseUrl: 'http://localhost:5000',
    endpoint: '/api/collections/active/assets',
    /* Budget for the whole manifest fetch. Deliberately short: this sits
       directly in front of the loading screen, so an unreachable backend
       costs a fixed sub-5s delay rather than an indefinite hang. */
    timeoutMs: 4000,
    /* Decode each candidate before swapping it in. Costs one extra request
       per asset (served from cache when Phaser then loads it), and buys
       per-asset instead of per-batch failure: one corrupt upload leaves
       that single brick on its built-in art, rather than showing Phaser's
       __MISSING texture in the middle of a level. */
    verify: true,
    log: true
  };

  function log(on, level, msg) {
    if (!on || typeof console === 'undefined') return;
    var fn = console[level] || console.log;
    fn.call(console, '[remote-assets] ' + msg);
  }

  /* Asset names arrive as whatever the uploader typed. Treat `brick0`,
     `brick0.png` and ` Brick0 ` as the same sprite, because the person
     uploading through the dashboard is picking a file, not typing a key. */
  function normalise(name) {
    return String(name == null ? '' : name)
      .trim()
      .replace(/\.(png|jpe?g|webp|gif|avif)$/i, '');
  }

  /* Uploads are stored locally as "/uploads/x.png" and on S3 as a full
     https URL. Resolve the former against the API host, pass the latter
     through untouched. */
  function absolutise(url, baseUrl) {
    if (!url) return null;
    if (/^(https?:)?\/\//i.test(url) || /^data:/i.test(url)) return url;
    return baseUrl.replace(/\/+$/, '') + (url.charAt(0) === '/' ? '' : '/') + url;
  }

  function fetchManifest(cfg) {
    var url = cfg.baseUrl.replace(/\/+$/, '') + cfg.endpoint;
    /* AbortController is the only thing that actually caps a fetch. A
       Promise.race leaves the request in flight, which on a phone means a
       dead socket held open behind a game that has already started. */
    var ctl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var timer = setTimeout(function () { if (ctl) ctl.abort(); }, cfg.timeoutMs);

    return fetch(url, {
      method: 'GET',
      signal: ctl ? ctl.signal : undefined,
      headers: { Accept: 'application/json' }
    })
      .then(function (res) {
        if (!res.ok) throw new Error('HTTP ' + res.status);
        return res.json();
      })
      .then(function (body) {
        var data = body && body.data;
        var assets = data && data.assets;
        return {
          assets: Array.isArray(assets) ? assets : [],
          collection: (data && data.activeCollection) || null
        };
      })
      .then(function (out) { clearTimeout(timer); return out; },
            function (err) { clearTimeout(timer); throw err; });
  }

  /* Resolves true/false — never rejects. A verification failure is a reason
     to skip one sprite, not to fail the batch. */
  function decodes(url, timeoutMs) {
    return new Promise(function (resolve) {
      var img = new Image();
      var done = false;
      var timer = setTimeout(function () { finish(false); }, timeoutMs);
      function finish(ok) {
        if (done) return;
        done = true;
        clearTimeout(timer);
        img.onload = img.onerror = null;
        resolve(ok);
      }
      img.onload = function () { finish(img.width > 0 && img.height > 0); };
      img.onerror = function () { finish(false); };
      img.src = url;
    });
  }

  /**
   * Overwrite entries of `sprites` with whatever the active collection holds.
   *
   * @param {Object} sprites   the game's SPRITES object — MUTATED in place
   * @param {Object} [options] see DEFAULTS
   * @returns {Promise<{applied: string[], skipped: string[], collection: ?Object, error: ?string}>}
   *          Always resolves. `applied` lists the sprite keys actually swapped.
   */
  function apply(sprites, options) {
    var cfg = Object.assign({}, DEFAULTS, options || {});
    var result = { applied: [], skipped: [], collection: null, error: null };

    if (!sprites || typeof sprites !== 'object') {
      result.error = 'no SPRITES object given';
      return Promise.resolve(result);
    }
    if (typeof fetch === 'undefined') {
      result.error = 'fetch unavailable';
      log(cfg.log, 'warn', 'fetch unavailable - keeping built-in art');
      return Promise.resolve(result);
    }

    /* Case-insensitive index of the keys we are willing to overwrite, built
       from the game's own object. A prototype-less map keeps inherited
       names (constructor, __proto__) out of the lookup entirely. */
    var index = Object.create(null);
    Object.keys(sprites).forEach(function (k) { index[k.toLowerCase()] = k; });

    return fetchManifest(cfg)
      .then(function (manifest) {
        result.collection = manifest.collection;

        /* A collection can legitimately hold several assets under the same
           name — re-uploading `brick0` adds a row rather than replacing one,
           so any collection that has been refreshed has duplicates in it.
           Resolve to the NEWEST by uploaded_at, explicitly.

           The endpoint happens to ORDER BY uploaded_at DESC today, so simply
           taking the first would usually work; that is exactly the kind of
           coupling that breaks silently when someone adds a sort parameter,
           and the failure mode is the game quietly serving stale art. */
        var best = Object.create(null);
        manifest.assets.forEach(function (a) {
          var name = normalise(a && a.name);
          var key = name && index[name.toLowerCase()];
          if (!key) { if (name) result.skipped.push(name); return; }
          var url = absolutise(a && a.url, cfg.baseUrl);
          if (!url) { result.skipped.push(name); return; }
          /* Missing/unparseable timestamps sort oldest, so a row that has one
             always beats a row that does not. */
          var when = Date.parse(a && a.uploaded_at);
          if (!isFinite(when)) when = -Infinity;
          if (!best[key] || when > best[key].when) best[key] = { key: key, url: url, when: when };
        });

        var candidates = Object.keys(best).map(function (k) { return best[k]; });
        if (!candidates.length) return [];

        if (!cfg.verify) {
          return candidates.map(function (c) { return [c, true]; });
        }
        return Promise.all(candidates.map(function (c) {
          return decodes(c.url, cfg.timeoutMs).then(function (ok) { return [c, ok]; });
        }));
      })
      .then(function (pairs) {
        pairs.forEach(function (pair) {
          var c = pair[0], ok = pair[1];
          if (!ok) { result.skipped.push(c.key + ' (did not decode)'); return; }
          sprites[c.key] = c.url;
          result.applied.push(c.key);
        });
        var title = result.collection && result.collection.title;
        log(cfg.log, 'log',
          'collection "' + (title || 'none') + '": ' +
          result.applied.length + ' sprite(s) replaced' +
          (result.applied.length ? ' -> ' + result.applied.join(', ') : ''));
        if (result.skipped.length) {
          log(cfg.log, 'log', 'skipped: ' + result.skipped.join(', '));
        }
        return result;
      })
      .catch(function (err) {
        /* The one place every failure converges. Nothing has been mutated
           on this path, so the game proceeds on its embedded art. */
        result.error = (err && err.name === 'AbortError')
          ? 'timed out after ' + cfg.timeoutMs + 'ms'
          : String((err && err.message) || err);
        log(cfg.log, 'warn', 'using built-in art (' + result.error + ')');
        return result;
      });
  }

  global.BBRemoteAssets = { apply: apply, defaults: DEFAULTS };
})(typeof window !== 'undefined' ? window : this);
