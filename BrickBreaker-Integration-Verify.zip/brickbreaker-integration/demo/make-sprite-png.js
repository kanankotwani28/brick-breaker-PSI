/* Minimal PNG writer — no dependencies.
 *
 * The demo needs a handful of throwaway sprites. Pulling in sharp or canvas
 * to draw a rectangle would add a native build step to a script whose whole
 * job is "make something obviously different from the built-in art", and it
 * would tempt someone into committing the generated files. Node ships zlib,
 * and an 8-bit RGBA PNG is a signature plus three chunks, so the encoder is
 * shorter than the dependency would be.
 *
 * Sprites are generated at run time and uploaded straight from memory, so no
 * image ever lands in the repo.
 */
'use strict';
const zlib = require('zlib');

/* CRC-32, as PNG specifies it (reflected, polynomial 0xEDB88320). */
const CRC_TABLE = (() => {
  const t = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c;
  }
  return t;
})();

function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const body = Buffer.concat([Buffer.from(type, 'ascii'), data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(body), 0);
  return Buffer.concat([len, body, crc]);
}

/**
 * Encode raw RGBA pixels as a PNG.
 * @param {number} w
 * @param {number} h
 * @param {Buffer} rgba  w*h*4 bytes
 * @returns {Buffer}
 */
function encodePNG(w, h, rgba) {
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8;    // bit depth
  ihdr[9] = 6;    // colour type 6 = truecolour + alpha
  ihdr[10] = 0;   // deflate
  ihdr[11] = 0;   // adaptive filtering
  ihdr[12] = 0;   // no interlace

  /* Each scanline is prefixed with its filter type. 0 (None) keeps the
     encoder trivial; these images are tiny and flat, so a smarter filter
     would save bytes nobody is counting. */
  const stride = w * 4;
  const raw = Buffer.alloc((stride + 1) * h);
  for (let y = 0; y < h; y++) {
    raw[y * (stride + 1)] = 0;
    rgba.copy(raw, y * (stride + 1) + 1, y * stride, (y + 1) * stride);
  }

  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr),
    chunk('IDAT', zlib.deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0))
  ]);
}

function hexToRgb(hex) {
  const s = hex.replace('#', '');
  return [parseInt(s.slice(0, 2), 16), parseInt(s.slice(2, 4), 16), parseInt(s.slice(4, 6), 16)];
}

/**
 * A flat slab with a light bevel and bold diagonal stripes.
 *
 * The stripes are the point. A plain colour swap is ambiguous at a glance —
 * the built-in bricks are also flat colours, so "did the upload work?"
 * becomes a colour-matching exercise in a screenshot. Diagonal banding
 * appears nowhere in the shipped art, so one look at the level answers it.
 */
function brickSprite(w, h, hex) {
  const [r, g, b] = hexToRgb(hex);
  const px = Buffer.alloc(w * h * 4);
  const edge = Math.max(2, Math.round(Math.min(w, h) * 0.10));
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      const onEdge = x < edge || y < edge || x >= w - edge || y >= h - edge;
      // 0/1 band, period ~18px, running at 45 degrees
      const band = (((x + y) / 18) | 0) % 2 === 0;
      let k = band ? 1.0 : 0.72;
      if (onEdge) k = 1.28;             // bevel: lighter than either band
      px[i] = Math.min(255, Math.round(r * k));
      px[i + 1] = Math.min(255, Math.round(g * k));
      px[i + 2] = Math.min(255, Math.round(b * k));
      px[i + 3] = 255;
    }
  }
  return encodePNG(w, h, px);
}

/** A filled circle with a highlight, transparent outside the disc. */
function ballSprite(size, hex) {
  const [r, g, b] = hexToRgb(hex);
  const px = Buffer.alloc(size * size * 4);
  const c = (size - 1) / 2;
  const rad = size * 0.46;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = (y * size + x) * 4;
      const d = Math.hypot(x - c, y - c);
      if (d > rad) { px[i + 3] = 0; continue; }
      /* Highlight up and to the left, falling off toward the rim. The
         falloff is wide and the range narrow on purpose: a tight, strong
         highlight clips to flat white over half the disc and the shaded
         remainder reads as a crescent moon rather than as a lit sphere. */
      const hl = Math.max(0, 1 - Math.hypot(x - c * 0.66, y - c * 0.66) / (rad * 1.85));
      const k = 0.80 + hl * 0.42;
      px[i] = Math.min(255, Math.round(r * k));
      px[i + 1] = Math.min(255, Math.round(g * k));
      px[i + 2] = Math.min(255, Math.round(b * k));
      // one-pixel feather so the disc is not visibly stair-stepped
      px[i + 3] = d > rad - 1 ? Math.round(255 * (rad - d)) : 255;
    }
  }
  return encodePNG(size, size, px);
}

module.exports = { encodePNG, brickSprite, ballSprite };
