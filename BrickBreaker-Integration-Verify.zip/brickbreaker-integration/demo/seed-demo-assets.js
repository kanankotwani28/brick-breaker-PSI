#!/usr/bin/env node
/* Demo driver: push a set of Brick Breaker sprites through the real asset
 * pipeline and leave the game pointed at them.
 *
 *   1. log in as admin                POST /api/auth/login
 *   2. create a collection            POST /api/collections
 *   3. upload each sprite             POST /api/admin/assets/upload
 *   4. make it the live one           POST /api/collections/:id/set-active
 *   5. read back what the game sees   GET  /api/collections/active/assets
 *
 * Every sprite is generated in memory and uploaded from a buffer, so running
 * this adds nothing to the repo. Step 5 is the one that matters: it hits the
 * same public endpoint remote-assets.js calls, so a green run here means the
 * game will see exactly these assets.
 *
 * Usage:
 *   node seed-demo-assets.js
 *   API_BASE_URL=http://192.168.1.39:5000 node seed-demo-assets.js
 *   node seed-demo-assets.js --revert     # stand the collection down again
 *
 * Requires Node 18+ (native fetch / FormData / Blob).
 */
'use strict';
const { brickSprite, ballSprite } = require('./make-sprite-png');

const BASE = (process.env.API_BASE_URL || 'http://localhost:5000').replace(/\/+$/, '');
const EMAIL = process.env.ADMIN_EMAIL || 'admin@gameanalytics.com';
const PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';
const TITLE = process.env.DEMO_COLLECTION || 'Brick Breaker Demo';
const REVERT = process.argv.includes('--revert');

/* Keys must match Brick Breaker's SPRITES object exactly — that is the whole
 * contract remote-assets.js matches on. brick0-5 are all on level 1, so the
 * swap is obvious without playing through anything.
 *
 * The ball is `rdBall0`, NOT `ball`. Play.create() resolves the ball texture
 * through the shop:
 *
 *     this.ballTex = shopItem('ball', SAVE.equippedId('ball')).art;
 *
 * and CLASSIC — what every new player has equipped — maps to `rdBall0`.
 * `ball` is only the fallback used when the equipped art is missing, so
 * uploading to it swaps a texture the game never draws. Both are listed so
 * the demo also covers a save that has fallen back. The other purchasable
 * balls are rdBall1/rdBall3/rdBall4. */
const SPRITES = [
  { name: 'brick0',  colour: '#FF2D95', kind: 'brick' },
  { name: 'brick1',  colour: '#00E5FF', kind: 'brick' },
  { name: 'brick2',  colour: '#7CFF00', kind: 'brick' },
  { name: 'brick3',  colour: '#FFD400', kind: 'brick' },
  { name: 'brick4',  colour: '#B04CFF', kind: 'brick' },
  { name: 'brick5',  colour: '#FF6A00', kind: 'brick' },
  { name: 'rdBall0', colour: '#2BFF88', kind: 'ball'  },
  { name: 'ball',    colour: '#2BFF88', kind: 'ball'  }
];

/* Source resolution, not display size. The game calls setDisplaySize() on
 * every sprite, so these only set how much detail survives scaling; 2x the
 * on-screen size is enough for any phone density. */
const BRICK_W = 260, BRICK_H = 108, BALL_D = 128;

const ok = (s) => `\x1b[32m${s}\x1b[0m`;
const bad = (s) => `\x1b[31m${s}\x1b[0m`;
const dim = (s) => `\x1b[2m${s}\x1b[0m`;

async function api(path, { method = 'GET', token, body, form } = {}) {
  const headers = {};
  if (token) headers.Authorization = `Bearer ${token}`;
  if (body) headers['Content-Type'] = 'application/json';
  const res = await fetch(BASE + path, {
    method,
    headers,
    body: form ? form : body ? JSON.stringify(body) : undefined
  });
  const text = await res.text();
  let json = null;
  try { json = JSON.parse(text); } catch { /* non-JSON error page */ }
  if (!res.ok) {
    const msg = (json && (json.error || json.message)) || text.slice(0, 200);
    throw new Error(`${method} ${path} -> ${res.status}: ${msg}`);
  }
  return json;
}

async function main() {
  console.log(`\n  Brick Breaker asset demo`);
  console.log(dim(`  backend: ${BASE}\n`));

  // --- 0. reachable? -------------------------------------------------
  try {
    await fetch(`${BASE}/health`, { signal: AbortSignal.timeout(5000) });
  } catch {
    console.error(bad(`  Cannot reach ${BASE}.`));
    console.error(`  Start it with:  cd gamebackend && npm run dev\n`);
    process.exit(1);
  }

  // --- 1. auth -------------------------------------------------------
  const login = await api('/api/auth/login', {
    method: 'POST',
    body: { email: EMAIL, password: PASSWORD }
  });
  const token = login?.data?.token || login?.token || login?.data?.accessToken;
  if (!token) throw new Error('login succeeded but no token in response');
  console.log(`  ${ok('OK')}  logged in as ${EMAIL}`);

  // --- 2. collection -------------------------------------------------
  /* Reuse the collection across runs rather than piling up duplicates —
     re-running the demo should be idempotent, not additive.

     sort/order/limit/offset are sent explicitly rather than left to the
     server's defaults. GET /api/collections does
     `allowedOrders.includes(order.toLowerCase())`, and on a request that
     omits `order` that is a TypeError on undefined — a 500. Sending them
     also keeps this script independent of whichever branch is checked out. */
  const q = '?sort=created_at&order=desc&limit=100&offset=0';
  const existing = await api('/api/collections' + q, { token });
  const list = existing?.data?.collections || existing?.data || [];
  let collection = (Array.isArray(list) ? list : []).find((c) => c.title === TITLE);

  if (REVERT) {
    if (!collection) { console.log(`  nothing to revert — no "${TITLE}" collection`); return; }
    await api(`/api/collections/${collection.id}`, { method: 'DELETE', token });
    console.log(`  ${ok('OK')}  deleted "${TITLE}" — game falls back to built-in art`);
    return;
  }

  if (collection) {
    console.log(`  ${ok('OK')}  reusing collection "${TITLE}" ${dim(collection.id)}`);
  } else {
    const created = await api('/api/collections', {
      method: 'POST', token, body: { title: TITLE }
    });
    collection = created?.data?.collection || created?.data;
    console.log(`  ${ok('OK')}  created collection "${TITLE}" ${dim(collection.id)}`);
  }

  // --- 3. clear previous demo uploads --------------------------------
  /* Uploading `brick0` again ADDS a row; it does not replace one. Without
     this, every run leaves another generation of duplicates in the
     collection. remote-assets.js resolves duplicates by uploaded_at and so
     still picks the newest, but a collection that grows by eight rows per
     demo is not something to hand a reviewer. */
  const wanted = new Set(SPRITES.map((s) => s.name.toLowerCase()));
  const all = await api('/api/admin/assets?limit=200&offset=0&sort=uploaded_at&order=desc', { token });
  const stale = (all?.data?.assets || []).filter(
    (a) => a.collection_id === collection.id && wanted.has(String(a.name || '').toLowerCase())
  );
  for (const a of stale) {
    try { await api(`/api/admin/assets/${a.id}`, { method: 'DELETE', token }); }
    catch (err) { console.log(`  ${bad('WARN')} could not delete old ${a.name}: ${err.message}`); }
  }
  if (stale.length) console.log(`  ${ok('OK')}  removed ${stale.length} asset(s) from a previous run`);

  // --- 4 & 5. generate + upload --------------------------------------
  let uploaded = 0;
  for (const s of SPRITES) {
    const png = s.kind === 'ball'
      ? ballSprite(BALL_D, s.colour)
      : brickSprite(BRICK_W, BRICK_H, s.colour);

    const form = new FormData();
    form.append('file', new Blob([png], { type: 'image/png' }), `${s.name}.png`);
    form.append('name', s.name);
    form.append('collection_id', collection.id);

    try {
      await api('/api/admin/assets/upload', { method: 'POST', token, form });
      console.log(`  ${ok('OK')}  uploaded ${s.name.padEnd(8)} ${dim(`${s.colour}  ${png.length} B`)}`);
      uploaded++;
    } catch (err) {
      console.log(`  ${bad('FAIL')} ${s.name}: ${err.message}`);
    }
  }

  // --- 5. make it live ------------------------------------------------
  await api(`/api/collections/${collection.id}/set-active`, { method: 'POST', token });
  console.log(`  ${ok('OK')}  "${TITLE}" is now the active collection`);

  // --- 6. read back through the PUBLIC endpoint the game uses ---------
  const live = await api('/api/collections/active/assets');
  const assets = live?.data?.assets || [];
  console.log(`\n  ${ok('VERIFIED')} GET /api/collections/active/assets returns ${assets.length} asset(s):`);
  for (const a of assets) console.log(`      ${String(a.name).padEnd(10)} ${dim(a.url)}`);

  console.log(`\n  ${uploaded}/${SPRITES.length} sprites uploaded. Reload the game to see them.`);
  console.log(dim(`  Undo with:  node seed-demo-assets.js --revert\n`));
}

main().catch((err) => {
  console.error(`\n  ${bad('ERROR')} ${err.message}\n`);
  process.exit(1);
});
