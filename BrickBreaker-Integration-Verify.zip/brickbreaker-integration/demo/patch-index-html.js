#!/usr/bin/env node
/* Apply the remote-asset integration to a copy of Brick Breaker's index.html.
 *
 * Brick Breaker is one self-contained 5.3 MB HTML file and it is not in this
 * repo — this branch carries the integration, not the game. So instead of
 * committing a patched copy, this script performs the patch, letting the
 * change stay reviewable as ~20 lines of code plus the two anchors below.
 *
 * It is also how the demo is reproduced: point it at your index.html, serve
 * the output, and the game is talking to the backend.
 *
 * Usage:
 *   node patch-index-html.js <source index.html> [output.html] [--api URL]
 *
 * Idempotent: re-running on an already-patched file is refused, not doubled.
 */
'use strict';
const fs = require('fs');
const path = require('path');

const args = process.argv.slice(2).filter((a) => a !== '--');
const apiIdx = args.indexOf('--api');
let API = 'http://localhost:5000';
if (apiIdx !== -1) { API = args[apiIdx + 1]; args.splice(apiIdx, 2); }

const SRC = args[0];
const OUT = args[1] || (SRC && SRC.replace(/\.html$/, '') + '.remote.html');

if (!SRC) {
  console.error('usage: node patch-index-html.js <index.html> [out.html] [--api URL]');
  process.exit(1);
}
if (!fs.existsSync(SRC)) {
  console.error(`not found: ${SRC}`);
  process.exit(1);
}

const MODULE = fs.readFileSync(path.join(__dirname, '..', 'remote-assets.js'), 'utf8');
let html = fs.readFileSync(SRC, 'utf8');
const before = html.length;

if (html.includes('BBRemoteAssets')) {
  console.error('already patched — nothing to do');
  process.exit(1);
}

/* The file is CRLF; match on a newline-agnostic anchor so the patch does not
   depend on which checkout you took it from. */
const NL = html.includes('\r\n') ? '\r\n' : '\n';

/* ---- anchor 1: make the boot handler async -------------------------------
   The game builds Phaser inside window's load handler. Awaiting there is what
   lets SPRITES be rewritten before Boot.preload() reads it — once the loader
   has started, the data URIs have already been handed over. */
const A1 = "window.addEventListener('load', function () {";
const a1Count = html.split(A1).length - 1;
if (a1Count !== 1) {
  console.error(`anchor 1 matched ${a1Count} times, expected exactly 1.`);
  console.error(`  looked for: ${A1}`);
  console.error(a1Count === 0
    ? '  the boot handler has changed shape.'
    : '  ambiguous — refusing to guess which one is the game boot.');
  process.exit(1);
}

/* Inserted BEFORE the loading overlay is hidden, deliberately. The overlay is
   the game's own spinner; holding it up for the duration of the fetch is what
   makes the round trip read as part of loading rather than as a frozen frame
   on a blank screen. */
const INJECT = [
  "window.addEventListener('load', async function () {",
  `  /* --- remote assets: swap in the live collection before Phaser loads --- */`,
  `  if (window.BBRemoteAssets) {`,
  `    try { await window.BBRemoteAssets.apply(SPRITES, { baseUrl: ${JSON.stringify(API)} }); }`,
  `    catch (e) { /* fail open - apply() already swallows its own errors */ }`,
  `  }`
].join(NL);

html = html.replace(A1, INJECT);

/* ---- anchor 2: define the module before the load event fires -------------
   Anywhere in <body> works: scripts all parse before window 'load', so the
   global exists by the time the handler runs. End of body keeps the diff at
   one insertion point and leaves the game's own blocks untouched.

   lastIndexOf, NOT replace(). The minified Phaser bundle contains the literal
   string "</body>" inside its SVG foreignObject helper (`i.push("</body>")`),
   and it sits on line 60 — thousands of lines before the real closing tag.
   String.replace() takes the FIRST match, which spliced this module into the
   middle of Phaser's source and produced a game that did not boot at all.
   The document's own </body> is by definition the last one. */
const A2 = '</body>';
const at = html.lastIndexOf(A2);
if (at === -1) {
  console.error('anchor 2 not found: no </body>');
  process.exit(1);
}
html = html.slice(0, at) +
       `<script>${NL}${MODULE}${NL}</script>${NL}` +
       html.slice(at);

fs.writeFileSync(OUT, html);
console.log(`patched  ${SRC}`);
console.log(`      -> ${OUT}`);
console.log(`   api    ${API}`);
console.log(`   size   ${before} -> ${html.length} bytes (+${html.length - before})`);
