# Brick Breaker → asset pipeline integration

Wires **Brick Breaker** (Phaser 3, one self-contained `index.html`) into the
same dynamic-asset pipeline the Flutter game already uses: upload a sprite in
the dashboard, mark its collection live, reload the game, see it in play.

This directory holds the **integration only**. The game itself is not in this
repo, and no image files are committed — the demo generates its sprites at run
time and uploads them from memory.

---

## How it works

Brick Breaker keeps every sprite in a single object:

```js
const SPRITES = { ball: "data:image/png;base64,...", brick0: "...", ... }
```

and `Boot.preload()` does `this.load.image(key, SPRITES[key])`. Phaser's loader
treats a URL and a data URI identically, so the entire integration is: **rewrite
the values of that object before the loader runs.** No scene, loader or draw
call changes.

```
dashboard ──upload──▶ POST /api/admin/assets/upload
                              │
                              ▼
                      collection marked active
                              │
   game boot ──GET /api/collections/active/assets──▶ [{name:"brick0", url:"/uploads/…"}]
                              │
                              ▼
                  SPRITES.brick0 = "http://…/uploads/…"
                              │
                              ▼
                    Boot.preload() loads the URL
```

Matching is by asset **name**. Upload something named `brick0` and it replaces
the `brick0` texture. `brick0`, `brick0.png` and ` Brick0 ` all match.

### Two guarantees

**Fail open.** A backend that is down, slow, unreachable or returning nonsense
leaves the game exactly as it was. Every failure path returns `SPRITES`
unmodified and the game boots on its built-in art. The fetch is capped by an
`AbortController` (4s default), so an unreachable backend costs a bounded delay,
not a hang.

**Never introduces a key.** Only keys already in `SPRITES` are overridden. An
upload named `xyz` is ignored rather than creating a texture nothing draws — and
one named `__proto__` cannot reach `Object.prototype`.

Each candidate is also decoded before being swapped in, so a corrupt upload
leaves that one sprite on its built-in art instead of showing Phaser's
`__MISSING` texture mid-level.

---

## Files

| | |
|---|---|
| `remote-assets.js` | The module. Drop into the game; exposes `BBRemoteAssets.apply()`. |
| `demo/patch-index-html.js` | Applies the integration to a copy of `index.html`. |
| `demo/seed-demo-assets.js` | Generates, uploads and activates a demo collection. |
| `demo/make-sprite-png.js` | Zero-dependency PNG writer (Node's `zlib`), so no binaries are committed. |

---

## Running the demo

**1. Backend**

```bash
cd gamebackend
npm install
npm run migrate && npm run seed
npm run dev
```

**2. Upload and activate the demo collection**

```bash
cd brickbreaker-integration/demo
node seed-demo-assets.js
```

Uploads six bricks and a ball, makes the collection live, then reads it back
through `GET /api/collections/active/assets` — the same public endpoint the game
calls. The demo sprites are boldly striped and neon, so one look at a level
tells you whether they came from the server.

**3. Patch and serve the game**

```bash
node patch-index-html.js /path/to/brickbreaker/www/index.html game.html
npx serve .        # or any static server
```

Open `game.html`. Level 1's bricks and the ball are the uploaded sprites, and
the console prints:

```
[remote-assets] collection "Brick Breaker Demo": 7 sprite(s) replaced -> brick0, brick1, …
```

**Undo:** `node seed-demo-assets.js --revert` deletes the collection; the game
falls back to its built-in art on the next reload.

### From a phone

The backend binds all interfaces, so put both devices on the same network and
point the game at your machine's LAN address:

```bash
node patch-index-html.js …/index.html game.html --api http://192.168.1.39:5000
API_BASE_URL=http://192.168.1.39:5000 node seed-demo-assets.js
```

---

## The patch

`patch-index-html.js` makes two edits, both anchored on text it verifies is
present — it aborts rather than guessing if the game's boot code has moved.

**1.** The boot handler becomes `async` and awaits the swap:

```js
window.addEventListener('load', async function () {
  if (window.BBRemoteAssets) {
    try { await window.BBRemoteAssets.apply(SPRITES, { baseUrl: "http://localhost:5000" }); }
    catch (e) { /* fail open */ }
  }
```

This sits *before* the loading overlay is hidden, so the round trip reads as
part of loading rather than as a frozen frame on a blank screen.

**2.** `remote-assets.js` is inlined before `</body>`. Inlined rather than
linked because the game ships as one file inside a Capacitor APK, where a
second `<script src>` would be another asset to package.

---

## Gotchas found while building this

Everything below was hit while getting the demo to run end-to-end on a clean
machine. None of it is changed by this branch — recorded so the next person
does not rediscover it.

### The in-play ball is `rdBall0`, not `ball`

`Play.create()` resolves the ball texture through the shop:

```js
this.ballTex = shopItem('ball', SAVE.equippedId('ball')).art;   // CLASSIC -> 'rdBall0'
```

`ball` is only the fallback when the equipped art is missing, so uploading to
`ball` swaps a texture the game never draws. The demo uploads both. Purchasable
balls are `rdBall1`, `rdBall3`, `rdBall4`; paddles are `padWood`, `padWide`,
`padSticky`, `padCannon`.

### Backend on `main` cannot read `.env` (fixed by PR #1)

`scripts/migrate.js` on `main` requires `../src/config/database` *before*
`dotenv.config()`. `database.js` builds its `Pool` at module load, so every
`DB_*` is still undefined and it silently falls back to `localhost:5432` as
user `suri` — which on a machine with any other Postgres running surfaces as:

```
SASL: SCRAM-SERVER-FIRST-MESSAGE: client password must be a string
```

PR #1 (`feature/unity-integration`) moves `dotenv.config()` to line 1 and fixes
it. Until that merges, export the `DB_*` vars into the environment instead of
relying on `.env`.

### `GET /api/collections` 500s without an `order` param

```js
allowedOrders.includes(order.toLowerCase())
```

`order` is undefined when the query omits it, so a bare `GET /api/collections`
is a `TypeError` → 500. `seed-demo-assets.js` always sends
`?sort=…&order=…&limit=…&offset=…`. Worth defaulting server-side.

### `npm run migrate` collides with the server's auto-migration

`scripts/migrate.js` applies `src/database/schema.sql`, while the server applies
the numbered `migrations/*.sql` on boot when `AUTO_MIGRATE !== 'false'`. Both
create the same triggers, and the second run dies with
`trigger "update_users_updated_at" for relation "users" already exists`.

On a clean database, **just start the server** — it applies all nine migrations
in order. Then run `scripts/seed.js` for the admin user.

### Re-uploading a name adds a row, it does not replace one

Uploading `brick0` twice leaves two assets named `brick0` in the collection.
`remote-assets.js` resolves duplicates to the newest by `uploaded_at` rather
than trusting the endpoint's current `ORDER BY`, and `seed-demo-assets.js`
deletes its previous uploads before re-running.

---

## Verified

Run end-to-end against a local backend (Postgres 18, local file storage, no S3):

- 8/8 sprites uploaded via `POST /api/admin/assets/upload`
- collection set active; `GET /api/collections/active/assets` returned exactly 8
- game booted and logged
  `[remote-assets] collection "Brick Breaker Demo": 8 sprite(s) replaced`
- in-game textures for `brick0`–`brick5` and `rdBall0` were `blob:` URLs
  (fetched over the network); `paddle`, `brickStone` and `heart` were still
  `data:` URIs, so only the uploaded keys moved
- level 1 built with **0** missing textures

---

## Notes for review

- **Nothing here changes existing behaviour.** No file outside this directory is
  touched. Without the patch step, the game is byte-identical to today.
- **No assets are committed.** `seed-demo-assets.js` generates PNGs in memory
  and uploads them from a buffer.
- **Re-running is idempotent.** The demo reuses its collection by title rather
  than piling up duplicates.
- **Demo credentials** come from `gamebackend/scripts/seed.js`
  (`admin@gameanalytics.com` / `admin123`) and are overridable via
  `ADMIN_EMAIL` / `ADMIN_PASSWORD`.
- **Not wired into the shipped APK.** The current Play build embeds its art. To
  ship this, run the patch as a build step before `npx cap sync android`.
