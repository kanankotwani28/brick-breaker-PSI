# Verify the Brick Breaker asset integration on your own device

Brick Breaker does what the Flappy Bird Unity SDK does on the asset side:
at boot it calls `GET /api/collections/active/assets` on the analytics
backend and swaps any asset whose **name matches one of its texture keys**
into the game, in place of the embedded art. Backend down → the game boots
normally on its built-in art (fail-open).

This folder is self-contained apart from the backend:

| File | What |
|---|---|
| `game.html` | Brick Breaker with the integration applied, pointed at `http://localhost:5000` |
| `brickbreaker-integration/` | the loader, the patch tool, demo scripts, full README |
| `VERIFY.md` | this file |

You need: **Node 18+**, **PostgreSQL 14+**, and a checkout of the
`Game-Dev` repo (for the backend + dashboard, both on `main`).

---

## 1. Backend (10 min the first time)

```bash
createdb game_analytics
cd Game-Dev/gamebackend
npm install
```

Known issue on `main` (fixed by PR #1): the scripts ignore `.env`, so export
the config as environment variables. PowerShell:

```powershell
$env:DB_HOST="localhost"; $env:DB_PORT="5432"; $env:DB_NAME="game_analytics"
$env:DB_USER="postgres";  $env:DB_PASSWORD="<your pg password>"
$env:USE_LOCAL_STORAGE="true"; $env:API_BASE_URL="http://localhost:5000"
$env:PORT="5000"; $env:JWT_SECRET="dev"; $env:JWT_REFRESH_SECRET="dev2"
$env:AUTO_MIGRATE="true"; $env:RATE_LIMIT_MAX_REQUESTS="10000"
node src/server.js          # applies all 9 migrations, then serves :5000
```

Second terminal, same env vars:

```powershell
node scripts/seed.js        # admin@gameanalytics.com / admin123
```

> Do NOT run `npm run migrate` on a fresh DB — it collides with the server's
> own migration pass (duplicate triggers). Just start the server.

## 2. Put assets in

Scripted (generates throwaway striped sprites, uploads, activates):

```bash
cd brickbreaker-integration/demo
node seed-demo-assets.js
```

Or by hand: dashboard `Game-Dev/gamedashboarrd` → `npm install && npm run dev`
→ http://localhost:5173 → log in → create a collection → **Upload Asset**
with names that match texture keys → set the collection **active for game**.

Naming (same idea as Flappy Bird's `pipe` / `bg.sky` convention — here the
name IS the Phaser texture key; case and extension are ignored):

| Upload as | Replaces |
|---|---|
| `brick0` … `brick5` | the six brick colours |
| `brickCracked0` … `5`, `brickBonus`, `brickStone` | damaged / bonus / stone bricks |
| `rdBall0` | the ball actually in play (`ball` is only a fallback — upload both) |
| `padWood`, `padWide`, `padSticky`, `padCannon` | paddles |
| `lvbg1` … `lvbg13` | level background paintings |

## 3. Run the game

```bash
python -m http.server 8100        # in this folder (or: npx serve .)
```

Open **http://localhost:8100/game.html** and press F12:

```
[remote-assets] collection "…": N sprite(s) replaced -> brick0, …
```

Level 1 renders the uploaded art. Mis-named uploads appear in a `skipped:`
line — that is the "why didn't mine show up" answer.

**The two checks that prove it:**
1. Replace one asset in the dashboard (same name again), hard-reload the
   game (Ctrl+F5) → only that sprite changes.
2. Stop the backend, reload the game → it boots on its embedded art, no
   errors. That is the fail-open contract.

## 4. On a phone (optional)

Same Wi-Fi; use the machine's LAN IP:

```bash
cd brickbreaker-integration/demo
node patch-index-html.js <path-to>/www/index.html game.html --api http://<LAN-IP>:5000
```

then open `http://<LAN-IP>:8100/game.html` on the phone. Allow ports
5000/8100 through the firewall when prompted. (`game.html` in this folder is
pinned to `localhost:5000`, so re-patching is required for remote devices.)
